using System;

namespace Unity.Cloud.Collaborate.Common {
    [Serializable]
    internal class StringArrayContainer : ArrayContainer<string>
    {}
}
