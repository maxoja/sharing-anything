#!/bin/bash

# Copyright (c) 2020 ITRS Group Ltd
# All rights reserved

# This script serves as a template for netprobe -discovery option

OS=$(eval "uname")
HOST=$(eval "hostname")

echo "{"
echo "    \"netprobe\": {"
echo "       \"discovered-properties\": {"
echo "            \"OS\": \"$OS\","
echo "            \"HOSTNAME\": \"$HOST\""
echo "        }"
echo "    }"
echo "}"
