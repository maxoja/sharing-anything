#!/bin/bash

query=$1
if  [ "${query}" = "" -o "${query}" = "-h" ]; then
	echo "Usage: $0 '<query>'"
	exit 1
fi

debug=$CYBERARK_WRAPPER_DEBUG
sdk=${CYBERARK_SDK:-/opt/CARKaim/sdk/clipasswordsdk}
appid=${CYBERARK_APPID:-ITRS-Geneos}

if [ -n "$debug" ]; then
  date +"%Y-%m-%d %H:%M:%S" >> cark.log
  echo "Query: $query, SDK: $sdk, appId: $appid" >> cark.log
fi

# The host process retries if passsword change is in process
"$sdk" GetPassword -p FailRequestOnPasswordChange=false -p AppDescs.AppID="$appid" -p Query="$query" -o PasswordChangeInProcess,Password

if [ -n "$debug" ]; then
  date +"%Y-%m-%d %H:%M:%S" >> cark.log
fi
